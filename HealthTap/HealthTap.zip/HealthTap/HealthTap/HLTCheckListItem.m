//
//  HLTCheckListItem.m
//  HealthTap
//
//  Created by Talha Khalid on 1/3/2016.
//  Copyright (c) 2016 Talha Khalid. All rights reserved.
//

#import "HLTCheckListItem.h"

@implementation HLTCheckListItem

@end