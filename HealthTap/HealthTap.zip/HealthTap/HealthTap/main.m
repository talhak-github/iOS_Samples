//
//  main.m
//  HealthTap
//
//  Created by Talha Khalid on 1/3/2016.
//  Copyright (c) 2016 Talha Khalid. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HLTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HLTAppDelegate class]));
    }
}
